<?php
$ar_buah = ["Pepaya", "Mangga", "Pisang", "Jambu" ];
// Cetak Buah ke Index ke 2
echo $ar_buah[2];
// Cetak Jumlah Buah
echo '<br/>Jumlah Buah ' . count($ar_buah);
// Cetak Seluruh Buah
echo '<ol>';
foreach($ar_buah as $buah){
    echo '<li>' . $buah . '<li/>';
}
echo '<ol/>';
// Tambahkan Buah
$ar_buah[]="Durian";
// Hapus Buah Index ke 1
unset ($ar_buah[1]);
// Ubah Buah Index ke 2 Menjadi Manggis
$ar_buah[2]="Manggis";
// Cetak seluruh Buah dengan Indexnya
echo '<ul>';
foreach($ar_buah as $k => $v){
    echo '<li> buah index - ' . $k .'adalah ' . $v . '<li/>';  
}
echo '</ul>';

?>