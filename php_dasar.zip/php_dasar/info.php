<?php
    phpinfo ();
    ?>