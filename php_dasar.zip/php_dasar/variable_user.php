<?php
// Definisikan Variable
$nama = 'Muhammad Andhika Pradana';
$umur = '20';
$berat = '64';

echo 'Nama : ' . $nama;
echo '<br/>Umur : ' . $umur . 'Tahun' ;
echo '<br/>Berat :' . $berat . 'Kg';

echo "<br/>Hello $nama Apakabar";

?>